package BusRoutes;


import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RegexMethods {
    public static void getcities(String text, char letter) {

        Pattern pattern2 = Pattern.compile("<h3>(" + letter + ".*)</h3>");
        Matcher matcher2 = pattern2.matcher(text);
        String cityname = "";
        while (matcher2.find()) {
            System.out.println(matcher2.group(1));
            cityname = matcher2.group(1);
            getbuscities(text, cityname);
            System.out.println("+++++++++++++++++++++++++++++++++++");
        }

    }

    public static void getbuscities(String text, String cityname) {
        Pattern pattern1 = Pattern.compile("<h3>(.*)</h3>|<strong><a\\shref(.*)>(.*)</a></strong>");
        Matcher matcher1 = pattern1.matcher(text);

        String[] cb = new String[174];
        String destinations = "";
        String busNumbers = "";
        int i = 0;
        while (matcher1.find()) {
            if (matcher1.group(1) != null) {
                //System.out.println("Destination: " + matcher1.group(1));
                destinations = matcher1.group(1);

            }
            if (matcher1.group(3) != null) {
                //System.out.println("Bus Number: " + matcher1.group(3));
                busNumbers = matcher1.group(3);
            }

            if (destinations.equals(cityname) && matcher1.group(3) != null) {
                System.out.println("Bus Number: " + matcher1.group(3));

            }

        }

    }

    public static String getRouteURL(String busNum, String text) {

        Pattern pattern = Pattern.compile("<a href=\"(.*)\">" + busNum + "");
        Matcher matcher = pattern.matcher(text);
        String url = "";
        if (matcher.find()) {
            url = "https://www.communitytransit.org/busservice" + matcher.group(1);

        }

        return url;

    }
    
    
    public static void getRoutes(String text) {
        String tabletext = "";
        Pattern table = Pattern.compile("<div\\sid=\"Weekday(.*)>([\\s\\S]*.*)<div\\sid=\"Saturday(.*)>|<div\\sid=\"Weekday(.*)>([\\s\\S]*.*)<p\\sclass=(.*)>");
        Matcher tablematcher = table.matcher(text);
        while(tablematcher.find()){
            if(tablematcher.group(1) != null)
                tabletext = tablematcher.group(2);
            if(tablematcher.group(5) != null){
                tabletext = tablematcher.group(5);
            }
        }

        Pattern pattern = Pattern.compile("<h2>Weekday<small>(.*)</small></h2>|<strong class=(.*)>(.*)</strong>|<p>(.*)</p>");
        Matcher matcher = pattern.matcher(tabletext);
        while (matcher.find()) {
            if(matcher.group(3) == null && matcher.group(4) == null){
                System.out.println("+++++++++++++++++++++++++++++++++++");
            }
            if(matcher.group(1) != null) {
                System.out.println("Destination: " + matcher.group(1));
            }
            
            if (matcher.group(3) != null) {
                System.out.print("Stop Number: " + matcher.group(3) + " ");
            }
            
            if (matcher.group(4) != null) {
                System.out.println(matcher.group(4));
            }
            

        }
        System.out.println("+++++++++++++++++++++++++++++++++++");

    }
}
