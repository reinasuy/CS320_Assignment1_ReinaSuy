package BusRoutes;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BusRouteStopSchedule {

    public static void main(String[] args) throws Exception {

        URLConnection bc = new URL("https://www.communitytransit.org/busservice/schedules/").openConnection();
        bc.setRequestProperty("user-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
        BufferedReader in = new BufferedReader(new InputStreamReader(bc.getInputStream()));
        String inputLine = "";
        String text = "";
        while ((inputLine = in.readLine()) != null) {
            text += inputLine + "\n";
        }

        in.close();

        char destination;
        String routeID;
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a letter that your destinations start with: ");
        destination = Character.toUpperCase(input.next().charAt(0));
        
        //gets the cities and the bus routes 
        RegexMethods.getcities(text, destination);

        System.out.println("Please enter a route ID as a string: ");
        routeID = input.next();

        //gets url for the route ID
        String url = RegexMethods.getRouteURL(routeID, text);
        System.out.println();
        System.out.println("The link for your route is: " + url);
        System.out.println();

        //route connection
        URLConnection bc2 = new URL(url).openConnection();
        bc2.setRequestProperty("user-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
        BufferedReader inn = new BufferedReader(new InputStreamReader(bc2.getInputStream()));
        String inputLine2 = "";
        String text2 = "";
        while ((inputLine2 = inn.readLine()) != null) {
            text2 += inputLine2 + "\n";
        }

        inn.close();
        
        //gets destinations and stops of the given route ID
        RegexMethods.getRoutes(text2);

    }
}
    